﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace SampleApp.Helperclasses
{
    public class ProxyBlocking
    {
        public Int32 booking_BlockID { get; set; }
        public Int32 booking_HostID { get; set; }
        public string booking_BlockIn { get; set; }
        public string booking_BlockOut { get; set; }
        public bool booking_IsBlocked { get; set; }

    }
}

